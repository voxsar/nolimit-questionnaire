
<?php $__env->startPush('title'); ?>
	Group Appraisals
<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
<div class="container">
	<div class="row mt-5">
		<div class="col-md-12 mt-5">
			<table class="table">
				<tr>
					<th>Name</th>
					<th colspan="3">Actions</th>
				</tr>
				<?php $__empty_1 = true; $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td><?php echo e($quiz->name); ?></td>
						
						<td>
							<a class="btn btn-success btn-block" href="<?php echo e(route("users.quizzes.show", [$user, $quiz])); ?>">Fill Appraisal</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/quizzes/grouplist.blade.php ENDPATH**/ ?>