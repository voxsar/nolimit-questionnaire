
<?php $__env->startPush('title'); ?>
	<?php echo e($quiz->name); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
	<div class="container">
		<?php if($quiz->exists() && $quiz->questions()->exists()): ?>
			<?php $__empty_1 = true; $__currentLoopData = $quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<?php if($quiz->answers()->exists()): ?>
					<?php $__empty_2 = true; $__currentLoopData = $quiz->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
						<?php if($answer->sections()->exists()): ?>
							<?php $__empty_3 = true; $__currentLoopData = $answer->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
								<?php echo e($section); ?>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
							<?php endif; ?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
					<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<?php endif; ?>
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/users/quizzes/print.blade.php ENDPATH**/ ?>