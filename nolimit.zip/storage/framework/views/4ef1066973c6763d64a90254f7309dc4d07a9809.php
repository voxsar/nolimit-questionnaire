<div class="form-group">
	<label ><?php echo e($label); ?></label>
	<input type="<?php if(isset($type)): ?><?php echo e($type); ?><?php endif; ?>" class="form-control" aria-describedby="emailHelp" value="<?php if(isset($value)): ?><?php echo e($value); ?><?php endif; ?>" name="<?php echo e($name); ?>" <?php if(isset($list)): ?>list="<?php echo e($list); ?>"<?php endif; ?>
		<?php if(isset($disabled) && $disabled != null): ?>disabled="<?php echo e($disabled); ?>"<?php endif; ?>>
	<?php if(isset($help)): ?>
		
	<?php endif; ?>
	 <?php if (isset($component)) { $__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Errors::class, ['name' => ''.e($name).'']); ?>
<?php $component->withName('errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17)): ?>
<?php $component = $__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17; ?>
<?php unset($__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div><?php /**PATH /home/vagrant/code/shoutout/resources/views/components/input.blade.php ENDPATH**/ ?>