
<?php $__env->startPush('title'); ?>
	User's Appraisals
<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('users.index')); ?>">Users</a></li>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('users.show', $user)); ?>"><?php echo e($user->name); ?></a></li>
	<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('users.quizzes.index', $user)); ?>">Appraisals</a></li>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<table class="table">
				<tr>
					<th>Name</th>
					<th>Actions</th>
					<th>Controls</th>
				</tr>
				<?php $__empty_1 = true; $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td><?php echo e($quiz->name); ?></td>
						<td>
							<?php if($quiz->answers()->where('user_id', $user->id)->exists()): ?>
								<a class="btn btn-warning" href="<?php echo e(route('users.quizzes.edit', [$user, $quiz])); ?>">Edit Appraisal</a>
							<?php else: ?>
								<a class="btn btn-success" href="<?php echo e(route('users.quizzes.show', [$user, $quiz])); ?>">Fill Appraisal</a>
							<?php endif; ?>
						</td>
						<td>
							<a class="btn btn-success" href="<?php echo e(route('users.quizzes.print', [$user, $quiz])); ?>">Print</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/users/quizzes/index.blade.php ENDPATH**/ ?>