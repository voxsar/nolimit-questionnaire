
<?php $__env->startPush('title'); ?>
	Add Choice to "<?php echo e($quiz->name); ?>"
<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('quizzes.index')); ?>">Appraisals</a></li>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('quizzes.show', $quiz)); ?>"><?php echo e($quiz->name); ?></a></li>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('quizzes.choices.index', [$quiz])); ?>">Choices</a></li>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('quizzes.choices.show', [$quiz, $choice])); ?>"><?php echo e($choice->choice); ?></a></li>
	<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('quizzes.choices.edit', [$quiz, $choice])); ?>">Edit</a></li>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
<form action="<?php echo e(route('quizzes.choices.update', [$quiz, $choice])); ?>" method="post">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['name' => 'choice','value' => ''.e($choice->choice).'','help' => 'Choice details e.g. Exceptional','label' => 'Choice']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['name' => 'rating_value','value' => ''.e($choice->rating_value).'','help' => 'Choice value e.g. 1 or 5','label' => 'Rating Value']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginalada24a059c331be0784ec187913c2ecfacd51890 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Textarea::class, ['name' => '','value' => ''.$choice->definition.'','help' => 'Definition of the Rating','label' => 'Definition']); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalada24a059c331be0784ec187913c2ecfacd51890)): ?>
<?php $component = $__componentOriginalada24a059c331be0784ec187913c2ecfacd51890; ?>
<?php unset($__componentOriginalada24a059c331be0784ec187913c2ecfacd51890); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
				<div class="form-group">
					<label ></label>
					<textarea class="form-control" name="definition"></textarea>
					<small class="form-text text-muted"></small>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label >Quiz Section</label>
					<select name="section" class="form-control">
						<?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<option value="<?php echo e($section); ?>"><?php echo e($section); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>
					</select>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<input type="submit" value="Update Question" class="btn btn-success">
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/quizzes/choices/edit.blade.php ENDPATH**/ ?>