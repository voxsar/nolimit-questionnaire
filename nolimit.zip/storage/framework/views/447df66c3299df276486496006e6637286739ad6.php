
<?php $__env->startPush('title'); ?>
	Edit: <?php echo e($quiz->name); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
<form action="<?php echo e(route('users.quizzes.update', [$user, $quiz])); ?>" method="post">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['disabled' => 'disabled','name' => 'name','value' => ''.e($user->name).'','help' => 'Name of the employee','label' => 'Name']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['disabled' => 'disabled','name' => 'emp_no','value' => ''.e($user->emp_no).'','help' => 'Employee no','label' => 'Employee No']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
			<div class="col-md-6">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['disabled' => 'disabled','name' => 'date_appraisal','value' => ''.e($date).'','help' => 'Appraisal Date','label' => 'Date','type' => 'date']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['disabled' => 'disabled','name' => 'designation','value' => ''.e($user->designation).'','help' => 'Designation of the Employee','label' => 'Designation']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
			<div class="col-md-6">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['disabled' => 'disabled','name' => 'evaluator','value' => ''.e($answer->evaluator).'','help' => 'Evaluator of the employee','label' => 'Evaluator','list' => 'evaluatorlist']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
				<datalist id="evaluatorlist">
					<?php $__empty_1 = true; $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<option value="<?php echo e($designation->listname); ?>" />
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
				</datalist>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['disabled' => 'disabled','name' => 'department','value' => ''.e($user->department).'','help' => 'Name of the department','label' => 'Department Name']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
			<div class="col-md-6">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['disabled' => 'disabled','name' => 'direct_supervisor','value' => ''.e($answer->direct_supervisor).'','help' => 'Direct Supervisor of the employee','label' => 'Direct Supervisor','list' => 'evaluatorlist']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['disabled' => 'disabled','name' => 'service_period','value' => ''.e($answer->service_period).'','help' => 'Service period of the Employee','label' => 'Service Period','type' => 'date']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
			<div class="col-md-6">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['disabled' => 'disabled','name' => 'department_head','value' => ''.e($answer->department_head).'','help' => 'Department Head of the employee','label' => 'Department Head','list' => 'evaluatorlist']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<?php echo $quiz->purpose; ?>

			</div>
		</div>
		<div class="row mt-3">
			<div class="col-md-12">
				<?php echo $quiz->instructions; ?>

			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<h4>Performance Rating Definitions:</h4>
			</div>
		</div>
		<?php $choices = $quiz->choices->groupBy('section')->first(); ?>
		<div class="row">
			<div class="col-md-12">
				<table class="table">
					<tr>
						<th>Score</th>
						<th>Rating Scale</th>
						<th>Definition</th>
					</tr>
					<?php $__empty_1 = true; $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($choice->rating_value); ?></td>
							<td><?php echo e($choice->choice); ?></td>
							<td><?php echo $choice->definition; ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
				</table>
			</div>
		</div>
		<div class="row mt-2">
			<div class="col-md-12">
				<h4>Section Scores:</h4>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<table class="table">
					<tr>
						<th>Sections</th>
						<th>Score</th>
						<th>Total</th>
					</tr>
					<?php $__empty_1 = true; $__currentLoopData = $table->unique('score'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($row['score']); ?></td>
							<td><?php echo e($row['answer']); ?></td>
							<td><?php echo e($row['total']); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
					<tr>
						<th>Total Score</th>
						<th><?php echo e($table->unique('score')->sum('answer')); ?></th>
						<th><?php echo e($table->unique('score')->sum('total')); ?></th>
					</tr>
					<tr>
						<th>Total in %</th>
						<th><?php echo e($table->unique('score')->sum('answer')); ?></th>
						<th><?php echo e($table->unique('score')->sum('total')); ?></th>
					</tr>

				</table>
			</div>
		</div>
		<div class="row mt-3">
			<div class="col-md-12">
				<input type="hidden" name="quiz" value="<?php echo e($quiz->id); ?>">
				<input type="hidden" name="next" value="<?php echo e($next); ?>">
				<button class="btn btn-primary" type="submit">Next Section</button>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/users/quizzes/edit.blade.php ENDPATH**/ ?>