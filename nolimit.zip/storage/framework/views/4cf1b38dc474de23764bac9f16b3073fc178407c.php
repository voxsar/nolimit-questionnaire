
<?php $__env->startPush('title'); ?>
	</h1><h2 class="text-center">Thank You!</h2><h1>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12 mt-4">
			<p class="text-center">Please do fill again next time!</p>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/quizzes/thankyou.blade.php ENDPATH**/ ?>