<?php if(isset($name)): ?>
	<?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<div class="alert alert-danger alert-dismissible fade show" role="alert">
			<small><?php echo e($message); ?></small>
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			</button>
		</div>
	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php endif; ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/components/errors.blade.php ENDPATH**/ ?>