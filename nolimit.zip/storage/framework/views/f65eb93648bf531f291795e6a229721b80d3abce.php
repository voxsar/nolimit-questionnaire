
<?php $__env->startPush('title'); ?>
	Edit Appraisal
<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('quizzes.index')); ?>">Appraisals</a></li>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('quizzes.show', $quiz)); ?>"><?php echo e($quiz->name); ?></a></li>
	<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('quizzes.edit', $quiz)); ?>">Edit</a></li>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
<form action="<?php echo e(route('quizzes.update', $quiz)); ?>" method="post">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['name' => 'name','help' => 'Name of the Appraisal','label' => 'Appraisal Name','value' => ''.e($quiz->name).'']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['name' => 'group','help' => 'Group of the Appraisal','label' => 'Appraisal Group','value' => ''.e($quiz->group).'']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginalada24a059c331be0784ec187913c2ecfacd51890 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Textarea::class, ['name' => 'purpose','help' => 'Purpose of Appraisal','label' => 'Purpose','value' => ''.$quiz->purpose.'']); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalada24a059c331be0784ec187913c2ecfacd51890)): ?>
<?php $component = $__componentOriginalada24a059c331be0784ec187913c2ecfacd51890; ?>
<?php unset($__componentOriginalada24a059c331be0784ec187913c2ecfacd51890); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginalada24a059c331be0784ec187913c2ecfacd51890 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Textarea::class, ['name' => 'instructions','help' => 'Instructions for the Appraisal','label' => 'Instructions','value' => ''.$quiz->instructions.'']); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalada24a059c331be0784ec187913c2ecfacd51890)): ?>
<?php $component = $__componentOriginalada24a059c331be0784ec187913c2ecfacd51890; ?>
<?php unset($__componentOriginalada24a059c331be0784ec187913c2ecfacd51890); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<input type="submit" value="Update Appraisal" class="btn btn-success">
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/quizzes/edit.blade.php ENDPATH**/ ?>