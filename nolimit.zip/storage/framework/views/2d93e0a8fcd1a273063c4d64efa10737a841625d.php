<div class="form-group">
	<label ><?php echo e($label); ?></label>
	<textarea name="<?php echo e($name); ?>" class="form-control summernote<?php echo e($name); ?>">
		<?php if(isset($value)): ?>
			<?php echo $value; ?>

		<?php endif; ?>
	</textarea>
	<?php if(isset($help)): ?>
		<small id="emailHelp" class="form-text text-muted"><?php echo e($help); ?></small>
	<?php endif; ?>
</div>
<?php $__env->startPush("scripts"); ?>
	<script type="text/javascript">
		$(document).ready(function() {
			$('.summernote<?php echo e($name); ?>').summernote();
		});
	</script>
<?php $__env->stopPush(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/components/textarea.blade.php ENDPATH**/ ?>