
<?php $__env->startPush('title'); ?>
	<?php echo e($quiz->name); ?></h1>
	<h3><?php echo e($section); ?></h3><h1>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('css'); ?>
	<style type="text/css">

	</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
<form action="<?php echo e(route('users.quizzes.answers.update', [$user, $quiz, $answer])); ?>" method="post">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="container-fluid questionr">

					<div class="row">
						<div class="m-1 p-2 col-1"></div>
						<div class="m-1 p-2 col-6"></div>
						<div class="p-0 m-0 col">
						</div>
					</div>
					<?php $count = 1; ?>
					<?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<?php if (! ($key == 'N/A')): ?>
							<div class="row bg-dark text-light">
								<div class="m-0 p-0 col-1">
									<small><?php echo e($count); ?></small>
								</div>
								<div class="m-0 p-0 col-6">
									<small><?php echo e($key); ?></small>
								</div>
								<div class="p-0 m-0 col">
									<div class="container-fluid p-0 m-0">
										<div class="p-0 m-0 row bg-dark text-light text-center">
											<?php $__empty_2 = true; $__currentLoopData = $choicetitles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
												<div class="p-1 m-0 col" style="line-height: 1;"><small><?php echo e($title->choice); ?></small></div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
											<?php endif; ?>
										</div>
									</div>
								</div>
							</div>
						<?php endif; ?>
						<?php $__empty_2 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
							<?php if($question->type == 1): ?>
								<div class="row border-bottom border-success">
									<div class="m-0 p-0 col-1">
										 <?php if (isset($component)) { $__componentOriginal1739ce5232d985dd5b10e8a32d7801d051495c84 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Roman::class, ['value' => ''.e($index).'']); ?>
<?php $component->withName('roman'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal1739ce5232d985dd5b10e8a32d7801d051495c84)): ?>
<?php $component = $__componentOriginal1739ce5232d985dd5b10e8a32d7801d051495c84; ?>
<?php unset($__componentOriginal1739ce5232d985dd5b10e8a32d7801d051495c84); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
									</div>
									<div class="m-0 p-0 col-6"><?php echo e($question->question); ?></div>
									<div class="m-0 p-0 col" >
										<div class="p-0 m-0 container-fluid">
											<div class="row ">
												<?php $__empty_3 = true; $__currentLoopData = $choicetitles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
													<div class="col d-flex justify-content-center ">
														<input class="form-control question group_<?php echo e($count); ?>" data-groupval="group_val_<?php echo e($count); ?>" data-group="group_<?php echo e($count); ?>" data-value="<?php echo e($choice->rating_value); ?>" type="radio" value="<?php echo e($choice->rating_value); ?>" name="questions[<?php echo e($question->id); ?>][answer]">
														<input type="hidden" name="questions[<?php echo e($question->id); ?>][category]" value="<?php echo e($question->category); ?>">

														<input type="hidden" name="questions[<?php echo e($question->id); ?>][section]" value="<?php echo e($question->section); ?>">

														<input type="hidden" name="questions[<?php echo e($question->id); ?>][question]" value="<?php echo e($question->id); ?>">

														<input type="hidden" name="questions[<?php echo e($question->id); ?>][type]" value="1">
													</div>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
												<?php endif; ?>
											</div>
											<div class="row">
												<div class="col">
													 <?php if (isset($component)) { $__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Errors::class, ['name' => 'questions.'.e($question->id).'.answer']); ?>
<?php $component->withName('errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17)): ?>
<?php $component = $__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17; ?>
<?php unset($__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php else: ?>
								<div class="row border-bottom border-success">
									<div class="m-0 p-0 col" >
										<div class="form-group">
											<label><?php echo e($question->question); ?></label>
											<input type="hidden" name="summary[<?php echo e($question->id); ?>][category]" value="<?php echo e($question->category); ?>">

											<input type="hidden" name="summary[<?php echo e($question->id); ?>][section]" value="<?php echo e($question->section); ?>">

											<input type="hidden" name="summary[<?php echo e($question->id); ?>][question]" value="<?php echo e($question->id); ?>">

											<input type="hidden" name="summary[<?php echo e($question->id); ?>][type]" value="2">
											<textarea class="form-control" name="summary[<?php echo e($question->id); ?>][answer]"></textarea>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col">
										 <?php if (isset($component)) { $__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Errors::class, ['name' => 'summary.'.e($question->id).'.answer']); ?>
<?php $component->withName('errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17)): ?>
<?php $component = $__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17; ?>
<?php unset($__componentOriginald8cba40cadbc03e4aa1d07e7ce9eadaa69861c17); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
									</div>
								</div>
							<?php endif; ?>
							<input type="hidden" name="current" value="<?php echo e($question->section); ?>"/>
							<input type="hidden" name="user" value="<?php echo e($user->id); ?>" />
							<input type="hidden" name="answer" value="<?php echo e($answer->id); ?>"/>
							<input type="hidden" name="next" value="<?php echo e($next); ?>"/>
							<input type="hidden" name="quiz" value="<?php echo e($quiz->id); ?>"/>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
						<?php endif; ?>

						<?php if (! ($key == 'N/A')): ?>
							<div class="row bg-light text-dark">
								<div class="m-1 p-2 col-1"></div>
								<div class="m-1 p-2 col-6">Score</div>
								<div class="p-1 m-1 col text-right">
									<p><span data-count="<?php echo e($choicetitles->count()); ?>" data-sumvalue="<?php echo e($choicetitles->max('rating_value')); ?>" class="group_val_<?php echo e($count); ?>">0</span></p>
								</div>
							</div>
						<?php endif; ?>
						<?php $count++; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>

					<div class="row bg-dark text-light">
						<div class="m-1 p-2 col-1"></div>
						<div class="m-1 p-2 col-6 text-right">
						</div>
						<div class="p-1 m-1 col">
							<p>Score</p>
						</div>
						<div class="p-1 m-1 col">
							<p class="text-right total_val">0</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<a href="<?php echo e(route('users.quizzes.answers.section', [$user, $quiz, $answer, $back])); ?>" class="btn btn-primary">Previous Section</a>
				<button type="submit" name="submit" class="btn btn-primary">Next Section</button>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
	<script type="text/javascript">
		$(document).ready(function(e) {
			$(".questionr").on('click', '.question:checked', function() {
				var group = 0;
				$("."+$(this).data('group')+":checked").each(function() {
					group += $(this).data('value')
					//sumvalue = (sumvalue * count) / 100
					//$("."+$(this).data('groupval')).html(group)
				})

				var sumvalue = $("."+$(this).data('groupval')).data('sumvalue')
				var count = $("."+$(this).data('groupval')).data('count')
				var percentage = ((group / (sumvalue * count)) * 100)
				percentage = Math.round(percentage)
				$("."+$(this).data('groupval')).html(percentage + "%")
				var count = 0
				$(".question:checked").each(function() {
					count += $(this).data('value')
					$(".total_val").html(count)
				})
				
			})
		});
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/quizzes/section.blade.php ENDPATH**/ ?>