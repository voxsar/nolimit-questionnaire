
<?php $__env->startPush('title'); ?>
	<?php echo e($quiz->group); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
<form action="<?php echo e(route('quizzes.groupselectuser', $group)); ?>" method="post">
	<?php echo csrf_field(); ?>
	<div class="container mt-5">
		<div class="row mt-5">
			<div class="col-md-12 mt-5">
				<img class="rounded mx-auto d-block" width="200" src="<?php echo e(asset('img/logo.png')); ?>">
			</div>
		</div>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['name' => 'emp_no','help' => 'Employee ID of the Employee','label' => 'Employee ID']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row mt-3">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<input type="hidden" name="quiz_id" value="<?php echo e($quiz->id); ?>">
				<input type="hidden" name="group" value="<?php echo e($group); ?>">
				<button type="submit" class="btn btn-primary btn-block">Fill Appraisal</button>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/quizzes/groups.blade.php ENDPATH**/ ?>