
<?php $__env->startPush('title'); ?>
	<?php echo e($quiz->name); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('quizzes.index')); ?>">Appraisals</a></li>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('quizzes.show', $quiz)); ?>"><?php echo e($quiz->name); ?></a></li>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<?php echo $quiz->purpose; ?>

		</div>
	</div>
	<div class="row mt-3">
		<div class="col-md-12">
			<?php echo $quiz->instructions; ?>

		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<h4>Performance Rating Definitions:</h4>
		</div>
	</div>
	<?php $__empty_1 = true; $__currentLoopData = $quiz->choices->groupBy('section'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sections): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<div class="row">
			<div class="col-md-12">
				<h5>Rating Definitions for <?php echo e($key); ?></h5>
				<table class="table">
					<tr>
						<th>Score</th>
						<th>Rating Scale</th>
						<th>Definition</th>
					</tr>
					<?php $__empty_2 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
						<tr>
							<td><?php echo e($choice->rating_value); ?></td>
							<td><?php echo e($choice->choice); ?></td>
							<td><?php echo $choice->definition; ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
					<?php endif; ?>
				</table>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<?php endif; ?>
	<div class="row mt-2">
		<div class="col-md-12">
			<h5>Section Scores:</h5>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6">
			<table class="table">
				<tr>
					<th>Sections</th>
					<th>Total</th>
				</tr>
				<?php $__empty_1 = true; $__currentLoopData = $table->unique('score'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td><?php echo e($row['score']); ?></td>
						<td><?php echo e($row['total']); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
				<tr>
					<th>Total Score</th>
					<th><?php echo e($table->unique('score')->sum('total')); ?></th>
				</tr>
				<tr>
					<th>Total in %</th>
					<th><?php echo e($table->unique('score')->sum('total')); ?></th>
				</tr>

			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/quizzes/show.blade.php ENDPATH**/ ?>