
<?php $__env->startPush('title'); ?>
	Add Question to "<?php echo e($quiz->name); ?>"
<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumbs'); ?>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('quizzes.index')); ?>">Appraisals</a></li>
	<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('quizzes.show', $quiz)); ?>"><?php echo e($quiz->name); ?></a></li>
	<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('quizzes.questions.index', $quiz)); ?>">Questions</a></li>
	<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('quizzes.questions.create', $quiz)); ?>">Create</a></li>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page'); ?>
<form action="<?php echo e(route('quizzes.questions.store', $quiz)); ?>" method="post">
	<?php echo csrf_field(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['name' => 'name','help' => 'Question details e.g. Displays in-depth understanding of job','label' => 'Question']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['name' => 'category','help' => 'Category of question e.g. \'Job Knowledge\'','label' => 'Category']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
				<datalist id="categorylist">
					<option value="Job Knowledge" />
				</datalist>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['name' => 'section','help' => 'Section under which the question falls under e.g. \'Section 01: Managerial Aspects\'','label' => 'Section']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
				<datalist id="sectionlist">
					<option value="Job Knowledge" />
				</datalist>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label >Question Type</label>
					<select name="type" class="form-control">
						<option value="1">MCQ</option>
						<option value="2">Comment</option>
					</select>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<input type="submit" value="Add Question" class="btn btn-success">
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/shoutout/resources/views/quizzes/questions/create.blade.php ENDPATH**/ ?>