@extends('layouts.client')
@push('title')
	</h1><h2 class="text-center">Thank You!</h2><h1>
@endpush
@push('breadcrumbs')
@endpush
@section('page')
<div class="container">
	<div class="row">
		<div class="col-md-12 mt-4">
			<p class="text-center">Please do fill again next time!</p>
		</div>
	</div>
</div>
@endsection